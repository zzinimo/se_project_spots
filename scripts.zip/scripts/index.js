const initialCards = [
  {
    name: "Toyota Camry",
    link: "https://pictures.dealer.com/a/autonationdrive/0846/65667807d383f66969470e467cf188ecx.jpg",
  },
  {
    name: "Lexus LS 460",
    link: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT6e9PNwd7YSCqMQX0IhDhEw2kd5AaavietqQ&s",
  },
  {
    name: "Honda Accord",
    link: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSgvSQV0-ZzBT7erg7gfYIHb7RvIk5zQ-4wZg&s",
  },
  {
    name: "Jeep Grand Cherokee",
    link: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQp7APF3F-v9ik-MomEpf_zYUs7hR7XwZF8PQ&s",
  },
  {
    name: "Nissan Altima",
    link: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSmPzUDuHS9N9j4zyXfu5GAX1BrfD0Ie1Q55Q&s",
  },
  {
    name: "Ford Explorer",
    link: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTQtkilOXMdYmFr3u2G_ltfMBhzgdNNC-RhNw&s",
  },
];

const profileEditButton = document.querySelector(".profile__edit-btn");

const editProfileModal = document.querySelector("#edit-profile-modal");

function openModal() {
  editProfileModal.classList.add("modal_opened");
}

profileEditButton.addEventListener("click", openModal);

const profileCloseButton = editProfileModal.querySelector(".modal__close-btn");

function closeModal() {
  editProfileModal.classList.remove("modal_opened");
}

profileCloseButton.addEventListener("click", closeModal);
