# Spots

Describe the project and functionality

## This webiste is designed to allow users to share experiences and places that they visit on a day to day basis, and to allow feedback on what other people think.

## Description:

This is a photo sharing website that allows users share cool and unique experiences and places that are visited on a day to day basis.

## Tech Stack

Figma was used for the website design template. HTML was used to structure the webiste and CSS was used to for styling purposes.

## Deployment

This wepage is deplayed to GitHub Pages

[Deployment link](https://zzinimo.github.io/se_project_spots/)
